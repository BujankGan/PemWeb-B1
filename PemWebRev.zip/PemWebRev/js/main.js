(function ($) {
    "use strict";

    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

    $('.validate-form').on('submit', function (e) {
        e.preventDefault();  // Prevent form submission to handle it with JS
        var check = true;

        for (var i = 0; i < input.length; i++) {
            if (validate(input[i]) == false) {
                showValidate(input[i]);
                check = false;
            }
        }

        // If all inputs are valid, proceed with login
        if (check) {
            // You can add your AJAX request here to check credentials from the server
            // Example login credentials check (this is a placeholder, replace with real authentication)
            var email = $('.validate-input input[name="email"]').val();
            var password = $('.validate-input input[name="pass"]').val();

            // Simulating a successful login (replace this logic with an actual login request to your backend)
            if (email === "admin@example.com" && password === "password123") {
                // If login is successful, redirect to admin.html
                window.location.href = 'admin.html';
            } else {
                alert('Invalid email or password');
            }
        }

        return check;
    });

    $('.validate-form .input100').each(function () {
        $(this).focus(function () {
            hideValidate(this);
        });
    });

    function validate(input) {
        if ($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if ($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                return false;
            }
        } else {
            if ($(input).val().trim() == '') {
                return false;
            }
        }
        return true; // Return true if input is valid
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
    }

})(jQuery);
